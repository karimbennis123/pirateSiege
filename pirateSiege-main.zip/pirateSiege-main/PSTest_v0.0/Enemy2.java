import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy2 extends Enemies
{
    /**
     * Act - do whatever the Enemy2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    GreenfootImage image1;
    GreenfootImage image2;
    GreenfootImage image3;
    GreenfootImage image4;
    GreenfootImage image5;
    GreenfootImage image6;
    GreenfootImage image7;
    GreenfootImage image8;
    GreenfootImage image9;
   
  public Enemy2(){
        image1 = new GreenfootImage("pirate2_img1.png");
        image2 = new GreenfootImage("pirate2_img2.png");
        image3 = new GreenfootImage("pirate2_img3.png");
        image4 = new GreenfootImage("pirate2_img4.png");
        image5 = new GreenfootImage("pirate2_img5.png");
        image6 = new GreenfootImage("pirate2_img6.png");
        image7 = new GreenfootImage("pirate2_img7.png");
        image8 = new GreenfootImage("pirate2_img8.png");
        image9 = new GreenfootImage("pirate2_img9.png");
        
        setImage(image1);
    }
    public void act()
    {
        if (Greenfoot.getRandomNumber(100) < 15)
        {
            move(-4);
            if (getImage() == image9)
            {
                setImage(image8);
            }
            else if (getImage() == image8)
            {
                setImage(image7);
            }
            else if (getImage() == image7)
            {
                setImage(image6);
            }
            else if (getImage() == image6)
            {
                setImage(image5);
            }
            else if (getImage() == image5)
            {
                setImage(image4);
            }
            else if (getImage() == image4)
            {
                setImage(image3);
            }
            else if (getImage() == image3)
            {
                setImage(image2);
            }
            else if (getImage() == image2)
            {
                setImage(image1);
            }
            else if (getImage() == image1)
            {
                setImage(image9);
            }// Add your action code here.
    }
 }
}
