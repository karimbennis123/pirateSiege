// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Buttons extends Actor
{
    protected GreenfootSound skeletonSound =  new GreenfootSound("SkeletonSound.wav");

    /**
     * Act - do whatever the Buttons wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
    }
}
